
HOW TO START Lyrics Buddy :

1) Open the command line on any folder and type 'create-react-app lyrics-buddy'
   and wait for the installation to create all files and folders.

2) Copy and replace the folders - 'src' and 'public' from my git to the new 'lyrics-buddy' folder.

3) Open the command line and enter the 'lyrics-buddy' folder.

3) type 'npm start' and the app will run on the browser

